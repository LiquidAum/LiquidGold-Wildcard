from .WildcardGold import WildcardGold

NODE_CLASS_MAPPINGS = {
    "WildcardGold": WildcardGold,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "WildcardGold": "🟡 Wildcard Gold",
}